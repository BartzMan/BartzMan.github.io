# Placeholders

## Design notes

Two Currents follows the logo: a blue cooling stroke and a red heating stroke that cross. The page is paper, indigo type, a warm panel, and a cool panel.

On a wide screen the hero is split down the middle. The left panel is warm and holds the headline about Katy heat. The right panel is cool and holds the gauge photograph, with no type on the photo. Two strokes cross the seam. On a phone the warm panel stacks first, then one crossing, then the photograph.

The signature is those two ribbons. A pair is fixed along the right edge and draws in as the page scrolls. Motion is off, and the strokes are fully drawn, when reduced motion is requested.

Three decisions a template would not make: the hero is a hot/cold split instead of a headline on a photograph; services are two named lists (cool and warm) plus a slim also-row, not cards; the five-star fact is a single oversized line with topic tags riding a ribbon, not a quote slider.

## Unconfirmed hours

Monday to Friday 8 AM to 8 PM. Saturday 8 AM to 5 PM. Sunday 8 AM to 1 PM. From the Google listing. Not yet confirmed.

## Images

No stock or AI images. Photographs are the business's Google photos: gauges (1), thumbs (2), vacuum gauge (4, shown small because the file is 576 pixels wide), logo (5).

## Wording that is connective

The three steps under The reading, and the gas-smell answer telling a visitor to leave and call 911 or the gas company.
