# Placeholders

## Design notes

Bay Current is East Bay fog and a charger on the siding: navy, fog grey, a gold call button, and an EV-green meter. The page reads like a charge session, not a brochure.

On a wide screen the hero is a split. The headline sits on fog at the left, low on the panel, and the charger photograph fills the right edge with no type on top of it. On a phone the photograph is first, cropped to the charger, and the headline block sits underneath on fog.

The signature is the charge meter: a vertical green bar on the left edge of a desktop screen, and a thin bar above the phone call strip. It fills with scroll and holds at 66% when motion is reduced.

Three decisions a template would not make: the meter is a fixed edge instrument rather than a progress line inside a hero; services are one vertical list with battery segments at five different fills, not a row of cards; the open-panel photograph overlaps the meter-strip photograph instead of sitting in a matched pair.

## Unconfirmed hours

Monday through Sunday, 7 AM to 6 PM. Taken from the Google listing. Not yet confirmed with the business.

## Images not from the business

- `images/ai-outlet-hands.jpg` — AI-generated placeholder of hands at a duplex outlet. Not a CenCal Electric job. No stock-photo page and no photographer.
- `images/ai-bay-dusk.jpg` — AI-generated placeholder of a one-story house at dusk in fog. Not a CenCal Electric job. No stock-photo page and no photographer.

Real photographs: `charger.jpg` (Google photo 5), `meters.jpg` (Google photo 1), `panels.jpg` (Google photo 4).

## Contrast

`#F4A259` and `#3DDC97` are not used as small text on fog. Gold is the call-button fill with navy text. EV green is the meter and the battery segments on navy. Where a green word sits on fog (the "5.0" line), the shade is `#0B6B48`.

## Wording that is connective, not a new fact

The sentence about the bars being a reading of the page, and the line that the text form opens a message on the visitor's phone.
