# Placeholders

## Design notes

Fresh Gloss is the moment a Katy rental looks new: white page, navy type, a gloss highlight that crosses a photo on hover, and a subway-tile field behind the tub. Gabarito for headlines, Schibsted Grotesk for text. Se habla español stays in the header.

On a wide screen the hero is type on the left and the navy-tile tub in a glossy card on the right. Nothing is centered on the photograph. On a phone the headline comes first and the card sits below it.

The signature is the gloss sweep on the photographs and the CSS subway-tile background in the resurfacing section.

Three decisions a template would not make: the offset gloss card instead of a full-bleed hero; paint and floors is an asymmetric stack (tall kitchen, galley, wide room) rather than three equal cards; the rating is a single huge 4.7, not a row of stars.

## Unconfirmed hours

Monday 8 AM to 6 PM. Tuesday 9 AM to 6 PM. Wednesday 9 AM to 7 PM. Thursday 7 AM to 9 PM. Friday 7 AM to 9 PM. Saturday 7 AM to 9 PM. Sunday listed as open 24 hours. From the Google listing. Not yet confirmed. The Sunday line is the listing, not a promise of when someone will arrive.

## Images

No stock or AI images. All five photographs are the business's Google photos.

## Contrast

Lavender `#B9B6C8` is grout only. Mint `#9ED9C5` is used on navy (the rating line and the text button) and as a rule, not as small text on white.
