# Sources

| On the page | Fact sheet |
|---|---|
| CenCal Electric | business_name |
| Electrician (JSON-LD) | jsonld_type |
| Richmond and the East Bay | service_area |
| Richmond, CA 94801 (no street) | service_area_basis mentions Richmond CA 94801; street omitted |
| (408) 310-5246 / +14083105246 | phones |
| Facebook https://www.facebook.com/108024198267769 | facebook |
| 5.0 stars on Google | rating 5, show_rating true |
| Every Google review: five stars | all_reviews_five_star |
| Reviewers mention reasonable cost and kindness | review_topics |
| Read the reviews on Google | maps_url |
| Outlet and switch repair; Panels and meters; EV charger installation; Lighting; Electrical repairs | services |
| Hours Mon–Sun 7 AM to 6 PM, labeled unconfirmed | hours_listing |
| Text form, no email | form_via text; emails empty |
| Charger photograph | photos file 5, hero |
| Meter cabinets photograph | photos file 1, gallery |
| Open panels photograph | photos file 4, gallery |
