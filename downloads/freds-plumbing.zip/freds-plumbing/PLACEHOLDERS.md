# Placeholders

## Design notes

Bergen Blueprint is a drawing sheet for a Bogota house: paper, blueprint blue, a brass pin, and a red valve for the call button. Headlines are Bree Serif. The page is a plan, not a brochure.

On a wide screen the hero is a title block on the left (sheet number, headline, call) and the house photograph on the right under a blueprint grid with supply, drain, and heat lines drawn on it. The headline is not sitting on the photo. On a phone the title block comes first and the photograph stacks under it.

The signature is the floor-plan drawing: kitchen, bath, basement, and utility, with blue supply, grey drain, and red heat, and brass pins for the four services.

Three decisions a template would not make: the hero is a drawing title block beside the photo; services are a mark/item/description schedule, not cards; the questions are numbered sheet notes, with the radiator photograph only beside the heat note.

## Unconfirmed hours

Monday through Saturday, 8 AM to 5 PM. Sunday closed. From the Google listing. Not yet confirmed.

## Images not from the business

All five photographs are AI placeholders, not Fred's Plumbing & Heating jobs. No stock-photo page and no photographer.

- `images/ai-house.jpg` — two-story clapboard house
- `images/ai-boiler.jpg` — boiler and pipes
- `images/ai-sink.jpg` — bathroom sink
- `images/ai-pipe-hands.jpg` — gloved hands on a copper fitting
- `images/ai-radiator.jpg` — cast-iron radiator

The business's Google photos were generic stock and were not used.

## Contrast

Brass `#C9A227` is not used as small text on paper. It is used for rules and pin dots, and it clears WCAG against blueprint blue. Body text is pencil `#45474B` or blueprint `#1D3B6E` on paper.
