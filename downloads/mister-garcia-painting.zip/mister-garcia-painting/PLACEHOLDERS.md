# Placeholders

## Design notes

Built-in treats the page as a run of Dallas cabinetry. Gallery white, forest green, and navy are the door colours. Bodoni Moda is the headline. Brass is only a pull, never small type.

On a wide screen the hero is two doors. The left door is the green kitchen photograph, full height. The right door is white, with a brass pull on its stile and the headline inside. On a phone the kitchen door is on top and the type door is below, pull still on the stile.

The signature is the cabinet-door grid: six services as doors with inset shadow lines and brass pulls, alternating forest, navy, and white so it reads as one wall, not four matching cards.

Three decisions a template would not make: the split door hero; the colour section is an unequal pair (wide navy built-ins, narrow white office); outside and commercial is a drawer-height exterior beside a smaller door, not a matched pair.

## Unconfirmed hours

Monday through Saturday, 8 AM to 5 PM. Sunday closed. From the Google listing. Not yet confirmed.

## Images

No stock or AI images. All five photographs are the business's Google photos: kitchen (3), navy built-ins (4), office (1), exterior (2), commercial interior (5).

## Contrast

Brass `#C5A15A` and oak `#B88A5A` are not used as small text on white. Brass is the pull shape. Oak is unused as text. Body text is navy or forest on gallery white, or white on forest and navy.

## Rating

The rating is intentionally not shown.
