# Sources

| On the page | Fact sheet |
|---|---|
| Mister Garcia Painting | business_name |
| HousePainter JSON-LD | jsonld_type |
| Dallas | service_area |
| Dallas, TX 75224, no street | service_area_basis ZIP; street omitted |
| (214) 837-6353 | phones |
| mistergarciapainting@gmail.com | emails |
| Facebook URL | facebook |
| Google reviews link with no rating and no count | maps_url; show_rating false |
| Se habla español | allowed_phrases |
| Six services | services |
| Hours, labeled unconfirmed | hours_listing |
| Email form | form_via email |
| Photos 3, 4, 1, 2, 5 | photos, used once each |
